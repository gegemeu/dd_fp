function z = dd_timesH_dd(x,y);
%DD_TIMESH_DD element by element product of two DD arrays

% Input:
% x,y = DD arrays

%
% Author G. Meurant
% May 2023
%

[rowx,colx] = size(x);
[rowy,coly] = size(y);

if rowx == 1 && colx == 1
 x = dd_times_dd(x, dd_ones(rowy,coly));
 rowx = rowy;
 colx = coly;
end % if

if rowy == 1 && coly == 1
 y = dd_times_dd(y, dd_ones(rowx,colx));
 rowy = rowx;
 coly = colx;
end % if


if rowx ~= rowy || colx ~= coly
 error('dd_timesH_dd: Incompatible dimensions of inputs')
end % if

z(rowx,colx) = struct('h',[],'l',[]);

for i = 1:rowx
 for j = 1:colx
  xh = x(i,j).h;
  xl = x(i,j).l;
  yh = y(i,j).h;
  yl = y(i,j).l;
  [ch,cl1] = ddfp_TwoProd(xh,yh);
  tl1 = xh * yl;
  tl2 = xl * yh;
  cl2 = tl1 + tl2;
  cl3 = cl1 + cl2;
  [zh,zl] = ddfp_fast2sum(ch,cl3);
  z(i,j) = struct('h',zh,'l',zl);
%   z(i,j) = dd_times_dd(x(i,j),y(i,j));
 end % for j
end % for i

z = class(z,'dd_fp');



