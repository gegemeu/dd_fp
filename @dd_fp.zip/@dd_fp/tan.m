function t = tan(a);
%TAN componentwise tangent of a DD floating point point number or matrix

% input in radians

%
% Author G. Meurant
% May 2023
%

[na,ma] = size(a);

if na == 1 && ma == 1
 t = dd_tan(a);
 
else
 t = a;
 [na,ma] = size(a);
 for i = 1:na
  for j = 1:ma
   t(i,j) = dd_tan(a(i,j));
  end % for j
 end % for j
 
end % if



