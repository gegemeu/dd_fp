function z = dd_times_fp(x,y);
%DD_TIMES_FP multiplication of a dd number by a floating-point number
% or arrays

% Muller's algorithm

% Input:
% x = double-double number, structure (x.h,x.l)
% y = double precision floating-point number
%
% Output:
% z = double-double number, structure (z.h,z.l)

%
% Author G. Meurant
% May 2023

[row,col] = size(x);
[rowy,coly] = size(y);

if row == 1 && col == 1 && rowy == 1 && coly == 1
 % two scalars
 xh = x.h;
 xl = x.l;
 [ch,cl1] = ddfp_TwoProd(xh,y);
 cl2 = xl * y;
 [th,tl1] = ddfp_fast2sum(ch,cl2);
 tl2 = tl1  + cl1;
 [zh,zl] = ddfp_fast2sum(th,tl2);
 z = struct('h',zh,'l',zl);
elseif row+col > 2 && rowy == 1 && coly == 1
 % x DD array and y fp scalar
 z(row,col) = struct('h',[],'l',[]);
 for i = 1:row
  for j = 1:col
   xh = x(i,j).h;
   xl = x(i,j).l;
   [ch,cl1] = ddfp_TwoProd(xh,y);
   cl2 = xl * y;
   [th,tl1] = ddfp_fast2sum(ch,cl2);
   tl2 = tl1  + cl1;
   [zh,zl] = ddfp_fast2sum(th,tl2);
   z(i,j) = struct('h',zh,'l',zl);
  end % for j
 end % for i
elseif row == 1 && col == 1 && rowy+coly > 2
 % x DD scalar and y fp array
 z(rowy,coly) = struct('h',[],'l',[]);
 for i = 1:rowy
  for j = 1:coly
   xh = x.h;
   xl = x.l;
   [ch,cl1] = ddfp_TwoProd(xh,y(i,j));
   cl2 = xl * y(i,j);
   [th,tl1] = ddfp_fast2sum(ch,cl2);
   tl2 = tl1  + cl1;
   [zh,zl] = ddfp_fast2sum(th,tl2);
   z(i,j) = struct('h',zh,'l',zl);
  end % for j
 end % for i
else
 % two arrays
 if col ~= rowy
  error('ddfp_times_fp: Incompatible dimensions')
 end % if
 zer = zeros(rowy,coly);
 ydd = ddfp_dec2dd(y,zer); % convert y to DD
 z = ddfp_dd_times_dd(x,ydd);
 
end % if row

z = class(z,'dd_fp');



