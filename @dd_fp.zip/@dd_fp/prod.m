function z = prod(a,dim);
%PROD prod function for DD numbers or arrays

%
% Author G. Meurant
% May 2023
%

[row,col] = size(a);

if row == 1 || col == 1
 s = dd_fp(1);
 rc = max(row,col);
 if col == 1
  a = transpose(a);
 end % if
 for i = 1:rc
  s = dd_times_dd(s, a(1,i));
 end % for i
 z = s;
 return
end % if row

if nargin < 2
 dim = 1;
end

if dim == 1
 % sum of the entries of columns
 z = dd_zeros(1,col);
 for i = 1:col
  s = dd_fp(1);
  for j = 1:row
   s = dd_times_dd(s, a(j,i));
  end % for j
  z(1,i) = s;
 end % for i
else
 % sum of the entries of rows
 z = dd_zeros(row,1);
 for i = 1:row
  s = dd_fp(1);
  for j = 1:col
   s = dd_times_dd(s, a(i,j));
  end % for j
  z(i,1) = s;
 end % for i
end % if dim



