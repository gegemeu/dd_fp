function d = det(x);
%DET determinant of a square matrix

%
% Author G. Meurant
% May 2023
%

[row,col] = size(x);

if row ~= col
 error('det: The matrix must be square')
end % if

if row == 1 && col == 1
 d = x;
 return
end % if

[L,U,P] = lu(x);
dU = diag(U);
d = prod(dU) * dd_fp(det(P));

