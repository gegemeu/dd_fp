function e = exp(a);
%EXP componentwise exponential of a DD floating point number or matrix

%
% Author G. Meurant
% May 2023
%

[na,ma] = size(a);

if na == 1 && ma == 1
 e = dd_exp(a);
 
else
 e = a;
 [na,ma] = size(a);
 for i = 1:na
  for j = 1:ma
   e(i,j) = dd_exp(a(i,j));
  end % for j
 end % for j
 
end % if



