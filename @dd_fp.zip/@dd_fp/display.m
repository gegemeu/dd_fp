function display(x);
%DISPLAY display for a DD floating point number

%
% Author G. Meurant
% May 2023
%

if isa(x,'dd_fp')
 disp(' ');
 disp([inputname(1),' = '])
 %disp(' ');
 disp_dd(x)
 disp(' ');
else
 x
end % if
