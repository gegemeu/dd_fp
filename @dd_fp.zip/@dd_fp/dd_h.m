function dech = dd_h(x);
%DD_H high part of a DD word 

%
% Author G. Meurant
% May 2023
%

[row,col] = size(x);
dech = zeros(row,col);

for i = 1:row
 for j = 1:col
  dech(i,j) = x(i,j).h;
 end % for j
end % for i

