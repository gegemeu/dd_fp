function c = mtimes(a,b);
%MTIMES product of two DD floating point numbers or matrices

% c = a * b

%
% Author G. Meurant
% May 2023
%

if ~isa(a,'dd_fp')
 a = dd_fp(a);
end % if 

if ~isa(b,'dd_fp')
 b = dd_fp(b);
end % if 

[na,ma] = size(a);
[nb,mb] = size(b);

if na == 1 && ma == 1 && nb == 1 && mb == 1 % scalar case
 c = dd_times_dd(a,b);
 return
end % if

if na == 1 && ma == 1 % scalar * matrix
 c = b;
 for i = 1:nb
  for j = 1:mb
   c(i,j) = dd_times_dd(a, b(i,j));
  end % for j
 end % for i
 return
end % if
   
if nb == 1 && mb == 1 % matrix * scalar
 c = a;
 for i = 1:na
  for j = 1:ma
   c(i,j) = dd_times_dd(b, a(i,j));
  end % for j
 end % for i
 return
end % if

if (na ~= 1) && (ma == 1) && (nb == 1) && (mb ~= 1) % outer product of vectors
%  c = mul_binflo(a,b);
error('outer product not yet implemented')
%  return
end % if

% matrix * matrix case

c = dd_times_dd(a,b);






