function z = ctranspose(x);
%CTRANSPOSE transpose of a (real) DD matrix

%
% Author G. Meurant
% May 2023
%

[row,col] = size(x);

z(col,row) = struct('h',[],'l',[]);

for i = 1:col
 for j = 1:row
  xh = x(j,i).h;
  xl = x(j,i).l;
  z(i,j).h = xh;
  z(i,j).l = xl;
 end % for j
end % for i

z = class(z,'dd_fp');
