function z = dd_times_dd_csrv(Add,Idd,sdd,x);
%DD_TIMES_DD_CSRV matrix-vector product of a CSR DD matrix and a DD vector

% Input:
% Add, Idd, sdd = DD matrix in CSR format from ddfp_dec2csr
% x = DD vector
%
% Output:
% z = vector, z = A x

%
% Author G. Meurant
% May 2023
%

row = length(sdd) - 1; % number of rows of A
z = dd_zeros(row,1);
diffs = diff(sdd); % number of entries in each row

for i = 1:row
 sA = sdd(i); % start of row i in Add
 ind = Idd(sA:sA+diffs(i)-1); % indices of row i
 yind = Add(sA:sA+diffs(i)-1);
 xind = x(ind);
 z(i) = dot(yind,xind);
end % for i

