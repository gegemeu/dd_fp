function Z = subsref(X,S)
%SUBSREF for DD floating point

if isequal(S.type,'.')
 Z = X;
else 
 sl = length(S.subs);
 indi = S.subs{1};
 if sl > 1
  indj = S.subs{2};
 else
  [nx,mx] = size(X);
  if nx == 1
   indi = 1;
   indj = S.subs{1};
  else
   indj = 1;
  end
 end
 [nx,mx] = size(X);
 if length(indi) == 1 && strcmp(indi,':')
  indi = [1:nx];
 end
 if length(indj) == 1 && strcmp(indj,':')
  indj = [1:mx];
 end

 n = length(indi);
 m = length(indj);
 ZZ(n,m) = struct('h',[],'l',[]);
 for i =1:n
  for j=1:m
   ZZ(i,j).h = X(indi(i),indj(j)).h;
   ZZ(i,j).l = X(indi(i),indj(j)).l;
  end % for j
 end % for i
 
 Z = class(ZZ,'dd_fp');
end

