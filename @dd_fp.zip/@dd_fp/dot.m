function zdot = dot(x,y);
%DOT dot product of two DD vectors

%
% Author G. Meurant
% May 2023
%

[rowx,colx] = size(x);
[rowy,coly] = size(y);

if rowx >1 && colx >1
 error('dot: The first argument must be a row or column vector')
end % if

if rowy >1 && coly >1
 error('dot: The second argument must be a row or column vector')
end % if

if rowx ~= 1 
 x = transpose(x);
end % if

if rowy == 1
 y = transpose(y);
end % if

zdot = dd_times_dd(x,y);

% zdot = class(zdot,'dd_fp');

