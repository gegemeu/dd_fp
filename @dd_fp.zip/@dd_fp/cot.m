function t = cot(a);
%COT componentwise cotangent of a DD floating point point number or matrix

% input in radians

%
% Author G. Meurant
% May 2023
%

[na,ma] = size(a);

if na == 1 && ma == 1
 t = dd_cot(a);
 
else
 t = a;
 [na,ma] = size(a);
 for i = 1:na
  for j = 1:ma
   t(i,j) = dd_cot(a(i,j));
  end % for j
 end % for j
 
end % if



