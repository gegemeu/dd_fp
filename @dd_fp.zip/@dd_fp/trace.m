function t = trace(a);
%TRACE trace of a DD matrix

%
% Author G. Meurant
% May 2023
%

d = diag(a);
t = sum(d);

