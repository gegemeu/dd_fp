function [V,R] = dd_orth_mgs_col(A,dreorth);
%DD_ORTH_MGS_COL (double) orthogonalisation of the columns of A
% Modified Gram-Schmidt by columns

% Input:
% A = DD matrix
% dreorth = 'dreorth' if we do a second orthogonalization
%
% Output:
% V = matrix whose columns span the same subspace as the columns of A
%     and V' V = I (up to rounding errors)
% R = matrix such that A = V R

%
% Author G.Meurant
% May 2023
%

if nargin == 1
 dreorth = 'nodreorth';
end

[m,n] = size(A);
V = dd_zeros(m,n);
R = dd_zeros(n,n);

% first orthogonalization

for k = 1:n
 v = A(:,k);
 for j = 1:k-1
%   alpha = v' * V(:,j);
  alpha = dd_times_dd(transpose(v), V(:,j));
  R(j,k) = alpha;
%   v = v - alpha * V(:,j);
  v = dd_minus_dd(v, dd_times_dd(alpha, V(:,j)));
 end % for j
 
 if strcmpi(dreorth,'dreorth') == 1
  % second orthogonalization
  for j=1:k-1
%    alpha = v' * V(:,j);
   alpha = dd_times_dd(transpose(v), V(:,j));
%    R(j,k) = R(j,k) + alpha;
   R(j,k) = dd_plus_dd(R(j,k), alpha);
%    v = v - alpha * V(:,j);
   v = dd_minus_dd(v, dd_times_dd(alpha, V(:,j)));
  end % for j
 end % if
 
 nv = normv(v);
 if nv.h + nv.l <= 1e-150
  fprintf('\n dd_orth_mgs_col: Breakdown, step %d, norm = %12.5e \n\n',k,double(nv))
  return
 end
 
 nv1 = dd_div_dd(dd_fp(1), nv);
%  V(:,k) = v / nv;
 V(:,k) = dd_times_dd(nv1, v);
 R(k,k) = nv;
 
end % for k

if m < n
 V = V(1:m,1:m);
 R = R(1:m,1:n);
end % if






