function c = cos(a);
%COS componentwise cosine of a DD floating point point number or matrix

% input in radians

%
% Author G. Meurant
% May 2023
%

[na,ma] = size(a);

if na == 1 && ma == 1
 c = dd_cos(a);
 
else
 c = a;
 [na,ma] = size(a);
 for i = 1:na
  for j = 1:ma
   c(i,j) = dd_cos(a(i,j));
  end % for j
 end % for j
 
end % if



