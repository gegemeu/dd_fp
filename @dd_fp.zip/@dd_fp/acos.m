function c = acos(a);
%ACOS inverse cosine function for a DD number or array

%
% Author G. Meurant
% May 2023
%

[na,ma] = size(a);

if na == 1 && ma == 1
 c = dd_acos(a);
 
else
 c = a;
 [na,ma] = size(a);
 for i = 1:na
  for j = 1:ma
   c(i,j) = dd_acos(a(i,j));
  end % for j
 end % for j
 
end % if