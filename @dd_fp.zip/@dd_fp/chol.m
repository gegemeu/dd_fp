function X = chol(A,s);
%CHOL Cholesky factorization of a DD matrix, ijk version

% this is a slow code, use it only for small matrices

% Input:
% A = symmetric positive definite matrix
%
% Output:
% X = upper or lower triangular matrix

%
% Author G. Meurant
% May 2023
%

low = 1;
n = size(A,1);
if nargin == 1 || strcmpi(s,'upper')
 low = 0;
end % if

d = dd_zeros(n,1);
temp = dd_zeros(n,1);

L = tril(A);

d(1) = A(1,1);
L(1,1) = dd_fp(1);

for i = 2:n
 temp(1:i) = A(i,1:i);
 for j = 1:i
  if j ~= i
   L(i,j) = temp(j) / d(j);
  end % if
  for k = j+1:i
   temp(k) = temp(k) - temp(j) * L(k,j);
  end % for k
 end   % for j
 d(i) = temp(i);
 L(i,i) = dd_fp(1);
end % for i 

dh = dd_h(d);
for i = 1:n
 if dh(i) <= 0
  error(' chol: The matrix is not positive definite')
 end % if
end % for i

d = sqrt(d);
D = diag(d);
L = L * D;
if low == 0
 X = transpose(L);
else
 X = L;
end % if


 
 
 
 
 
