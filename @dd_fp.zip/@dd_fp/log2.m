function z = log2(x);
%LOG2 base 2 logarithm of a DD number 

%
% Author G. Meurant
% %ay 2023
%

ln2 = log(dd_fp(2));
ln21 = dd_div_dd(dd_fp(1), ln2);

z = dd_times_dd(ln21, log(x));

