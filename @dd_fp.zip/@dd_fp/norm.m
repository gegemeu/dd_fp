function znorm = norm(x,p);
%NORM norm of a DD vector or matrix

%
% Author G. Meurant
% May 2023
%

[row,col] = size(x);

if nargin == 1
 p = 'Frob';
end % if

if row == 1 || col == 1
 znorm = normv(x);
 return
end % if

if p == 2
 error('norm: The Euclidean norm of a DD matrix is not implemented')
end % if

if p == 1
 a = abs(x);
 y = sum(a,2);
 znorm = max(y);
 return
end % if

if p == Inf
 a = abs(x);
 y = sum(a,1);
 znorm = max(y);
 return
end % if

if ischar(p) && strcmpi(p,'Frob')
 % Frobenius norm
 a = dd_timesH_dd(x,x);
 znorm = sqrt(sum(sum(a)));
 return
end % if

error('norm: This norm does not exist')



