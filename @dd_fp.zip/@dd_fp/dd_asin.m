function c = dd_asin(a);
%DD_ASIN inverse sine function for a DD number

%
% Author G. Meurant
% May 2023
%

nbits = 104;

dec = dd_h(a) + dd_l(a);

if abs(dec) > 1
 error(' dd_asin: The argument must have an absolute value less than or equal to 1')
end % if

if abs(dec) < 2^(-nbits)
 c = dd_fp(0);
 return
end % if

if abs(dec - 1) < 2^(-nbits)
 dd_pi = dd_fp('pi');
 c = dd_div_dd(dd_pi,dd_fp(2));
 return
end % if

if abs(dec + 1) < 2^(-nbits)
  dd_pi = dd_fp('pi');
 c = dd_div_dd(dd_pi,dd_fp(-2));
 return
end % if

if abs(dec) < 2^(-nbits/2)
 c = a;
 return
end % if

pS0 = dd_fp(1.66666666666666657415e-01);
pS1 = dd_fp(-3.25565818622400915405e-01);
pS2 = dd_fp(2.01212532134862925881e-01);
pS3 = dd_fp(-4.00555345006794114027e-02);
pS4 = dd_fp(7.91534994289814532176e-04);
pS5 = dd_fp(3.47933107596021167570e-05);
qS1 = dd_fp(-2.40339491173441421878e+00);
qS2 = dd_fp(2.02094576023350569471e+00);
qS3 = dd_fp(-6.88283971605453293030e-01);
qS4 = dd_fp(7.70381505559019352791e-02);

one = dd_fp(1);
dd_pi = dd_fp('pi');
pis2 = dd_div_dd(dd_pi,dd_fp(2));
two = dd_fp(2);

if abs(dec) < 0.5
 
 t = dd_times_dd(a, a);
 p = dd_times_dd(t, dd_plus_dd(pS0, dd_times_dd(t, dd_plus_dd(pS1,...
  dd_times_dd(t, dd_plus_dd(pS2, dd_times_dd(t,...
  dd_plus_dd(pS3, dd_times_dd(t, dd_plus_dd(pS4, dd_times_dd(t, pS5)))))))))));
 q = dd_plus_dd(one, dd_times_dd(t, dd_plus_dd(qS1, dd_times_dd(t,...
  dd_plus_dd(qS2, dd_times_dd(t, dd_plus_dd(qS3, dd_times_dd(t, qS4))))))));
 w = dd_div_dd(p, q);
 c =  dd_plus_dd(a, dd_times_dd(a, w));
 return
 
else
 w = dd_minus_dd(one, abs(a));
 t = dd_times_dd(w, dd_fp(0.5));
 p = dd_times_dd(t, dd_plus_dd(pS0, dd_times_dd(t, dd_plus_dd(pS1, dd_times_dd(t, dd_plus_dd(pS2,...
  dd_times_dd(t, dd_plus_dd(pS3, dd_times_dd(t, dd_plus_dd(pS4, dd_times_dd(t, pS5)))))))))));
 q =  dd_plus_dd(one, dd_times_dd(t, dd_plus_dd(qS1, dd_times_dd(t, dd_plus_dd(qS2,...
  dd_times_dd(t, dd_plus_dd(qS3, dd_times_dd(t, qS4))))))));
 s = sqrt(t);
 
 if abs(dec) > 0.975
  w = dd_div_dd(p, q);
  t = dd_minus_dd(pis2, dd_times_dd(two, dd_plus_dd(s, dd_times_dd(s, w))));
  
 else
  w  = s;
  c  = dd_div_dd( dd_minus_dd(t, dd_times_dd(w, w)) , dd_plus_dd(s, w));
  r  = dd_div_dd(p, q);
  t = dd_minus_dd(pis2, dd_times_dd(two, dd_plus_dd(dd_minus_dd(dd_times_dd(s, r), c), w)));
 end % if
 
 c = t;
 if dec < 0
  c = dd_times_dd(c,dd_fp(-1));
 end % if
 
end % if

