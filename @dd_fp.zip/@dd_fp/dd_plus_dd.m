function z = dd_plus_dd(x,y);
%DD_PLUS_DD addition of two dd words or arrays

% Muller's algorithm

% Input:
% x = double-double number, structure (x.h,x.l)
% y = double-double number, structure (y.h,y.l)
%
% Output:
% z = double-double number, structure (z.h,z.l)

%
% Author G. Meurant
% May 2023

[row,col] = size(x);

if row == 1 && col == 1
 xh = x.h;
 xl = x.l;
 yh = y.h;
 yl = y.l;
 [sh,sl] = ddfp_2sum(xh,yh);
 [th,tl] = ddfp_2sum(xl,yl);
 c = sl + th;
 [vh,vl] = ddfp_fast2sum(sh,c);
 w = tl + vl;
 [zh,zl] = ddfp_fast2sum(vh,w);
 z = struct('h',zh,'l',zl);
else
 [rowy,coly] = size(y);
 if rowy ~= row || coly ~= col
  error('dd_plus_dd: The two arrays must have the same dimension')
 end % if rowy
 z(row,col) = struct('h',[],'l',[]);
 for i = 1:row
  for j = 1:col
   xh = x(i,j).h;
   xl = x(i,j).l;
   yh = y(i,j).h;
   yl = y(i,j).l;
   [sh,sl] = ddfp_2sum(xh,yh);
   [th,tl] = ddfp_2sum(xl,yl);
   c = sl + th;
   [vh,vl] = ddfp_fast2sum(sh,c);
   w = tl + vl;
   [zh,zl] = ddfp_fast2sum(vh,w);
   z(i,j) = struct('h',zh,'l',zl);
  end % for j
 end % for i
 
end % if row

z = class(z,'dd_fp');

