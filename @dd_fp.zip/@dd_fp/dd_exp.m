function e = dd_exp(a);
%DD_EXP exponential of a DD number

%
% Author G. Meurant
% May 2023
%

decp = dd_h(a) + dd_l(a);
decy = abs(decp);
nbits = 104;

if decy < 2^(-nbits)
 e = dd_fp(1);
 return
end % if

if decp > 700
 error(' dd_exp: a is too large') 
end % if

if decp < 0 && decy > 750
 e = dd_fp(0);
 return
end % if

% ln2 = 0.69314718055994528622676398299518; % log(2)
ln2 = dd_fp(6.931471805599453e-01,2.319046813846300e-17); 

% ln21 = 1.4426950408889634073599246810018921374; % 1 / log(2)
one = dd_fp(1);
ln21 = dd_div_dd(one,ln2);

% c1 = 0.693359375000000000; % 355 / 512
c1 = dd_fp(6.933593750000000e-01);
% c2 = -2.121944400546905827679e-4;
c2 = dd_minus_dd(ln2,c1); % c1 + c2 = log(2)

aln21 = dd_times_dd(a,ln21);
n = round(dd_h(aln21) + dd_l(aln21));  
decn = n;

g = dd_minus_dd( (dd_minus_dd(a, dd_times_fp(c1,n))), dd_times_fp(c2,n)); % (a - n * c1) - n * c2;

% p1 = floatp(1.66666666666666019037e-01,nbits);
p1 = dd_fp(1.666666666666601e-01,9.037e-17);
% p2 = floatp(-2.77777777770155933842e-03,nbits);
p2 = dd_fp(-2.777777777701559e-03,3.3842e-19);
% p3 = floatp(6.61375632143793436117e-05,nbits);
p3 = dd_fp(6.613756321437934e-05,3.6117e-21);
% p4 = floatp(-1.65339022054652515390e-06,nbits);
p4 = dd_fp(-1.653390220546525e-06,1.5390e-22);
% p5 = floatp(4.13813679705723846039e-08,nbits); 
p5 = dd_fp(4.138136797057238e-08,4.6039e-24);

t = dd_times_dd(g,g);

% e  = g - t * (p1 + t * (p2 + t * ( p3 + t * (p4 + t * p5) ) ) );
e  = dd_minus_dd(g, dd_times_dd(t, dd_plus_dd(p1, dd_times_dd(t,...
 dd_plus_dd(p2, dd_times_dd(t, dd_plus_dd(p3, dd_times_dd(t,...
 dd_plus_dd(p4, dd_times_dd(t,p5) ) ) ) ) ) ) ) ) );

one = dd_fp(1);
two = dd_fp(2);
y = dd_minus_dd(one, dd_minus_dd( dd_div_dd( dd_times_dd(g,e),...
 dd_minus_dd(e,two) ), g));  % 1 - ( [(g * c) / (c - 2)] - g); 

if decn == 0
 e = y;
else
 n2 = 2^decn;
 e = dd_times_dd(y,dd_fp(n2)); % ex = y * 2^n
end % if
 
 
 
 
 


