function z = diag(x,k);
%DIAG diagonal function for a DD matrix or vector

%
% Author G. Meurant
% May 2023
%

[na,ma] = size(x);

if nargin == 1
 k = 0;
end % if

if na ~= 1 && ma ~= 1
 % extract a diagonal
 if abs(k) >= na
  error('diag: k is too large')
 end % if
 B = diag(diag(ones(na,ma),k),k) == 1;
 z = x(B);
 return
end % if

% if bina is a vector construct a matrix from it
if na == 1
 x = transpose(x);
end % if

lbina = length(x);
n = lbina + abs(k); % order of the (square) matrix
z  = dd_zeros(n,n); % create a zero matrix of order n
B = diag(diag(ones(n,n),k),k) == 1;
z(B) = x;








