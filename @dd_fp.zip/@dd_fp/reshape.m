function x = reshape(x,varargin)
%RESHAPE reshape function for DD vectors or arrays

%
% Author G. Meurant
% May 2023
%

xh = dd_h(x);
xl = dd_l(x);

xhr = reshape(xh, varargin{:});
xlr = reshape(xl, varargin{:});

x = dd_fp(xhr, xlr);

