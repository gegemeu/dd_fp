function c = dd_tan(a);
%DD_TAN tangent function for a DD number

%
% Author G. Meurant
% May 2023
%

nbits = 104;

dec = dd_h(a) + dd_l(a);
dec = abs(dec);
dec = mod(dec,2*pi);

if abs(dec - pi/2) < 2^(-nbits)
 fprintf(' dd_tan: Caution, the tangent is large, may be Inf \n')
 c = dd_fp(1e300); % ???????
 return
end % if

if abs(dec - 3*pi/2) < 2^(-nbits)
 fprintf(' dd_tan: Caution, the tangent is large, may be -Inf \n')
 c = dd_fp(-1e300); % ???????
 return
end % if

c = dd_div_dd(dd_sin(a), dd_cos(a));



