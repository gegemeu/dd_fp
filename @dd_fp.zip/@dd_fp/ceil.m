function v = ceil(v);
%CEIL ceil for DD numbers

%
% Author G. Meurant
% May 2023
%

x1 = ceil(dd_h(v));
x2 = zeros(size(x1));
I = find(x1 == dd_h(v));
vl = dd_l(v);
x2(I) = ceil(vl(I));
[x1,x2] = ddfp_fast2sum(x1,x2); 
v = dd_fp(x1,x2);

