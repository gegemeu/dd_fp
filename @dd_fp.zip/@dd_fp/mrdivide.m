function c = mrdivide(a,b);
%MRDIVIDE  division of two DD floating point numbers or matrices
% a / b

% for matrices, c * b = a, c is a row vector

%
% Author G. Meurant
% May 2023
%

if ~isa(a,'dd_fp')
 a = dd_fp(a);
end % if 

if ~isa(b,'dd_fp')
 b = dd_fp(b);
end % if 

[na,ma] = size(a);
[nb,mb] = size(b);

if na == 1 && ma == 1 && nb == 1 && mb == 1
 c = dd_div_dd(a,b);
 
else
 if nb ~= mb
  error(' mrdivide: b must be a square matrix')
 end % if
 if ma ~= mb
  error(' mrdivide: incompatible dimensions')
 end % if
 
 bt = ctranspose(b);
 ta = ctranspose(a);
 y = mldivide(bt, ta);
 c = ctranspose(y);
 
end % if




