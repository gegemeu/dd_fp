function c = mldivide(a,b);
%MLDIVIDE  division of two DD floating point numbers or matrices
% a \ b which is b / a for scalars

%
% Author G. Meurant
% May 2023
%

if ~isa(a,'dd_fp')
 a = dd_fp(a);
end % if 

if ~isa(b,'dd_fp')
 b = dd_fp(b);
end % if 

[na,ma] = size(a);
[nb,mb] = size(b);

if na == 1 && ma == 1 && nb == 1 && mb == 1
 % two scalars
 c = dd_div_dd(b,a);
 
else
 if na ~= ma
  error(' mldivide: a must be a square matrix')
 end % if
 if na ~= nb
  error(' mldivide: Incompatible dimensions')
 end % if
 
 % LU factorization of a
 [L,U,~,p] = lu(a);
 c = dd_fp(zeros(na,mb));
 for k = 1:mb
  c(:,k) = lu_solver(b(:,k),L,U,p);
 end % for k
 
end % if



