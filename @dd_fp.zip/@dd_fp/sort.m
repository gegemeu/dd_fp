function [s,I] = sort(x,dim,mode);
%SORT sort function for DD arrays

%
% Author G. Meurant
% May 2023
%

if nargin == 1
 dim = 1;
 mode = 'ascend';
end % if
if nargin == 2
 mode = 'ascend';
end % if
[row,col] = size(x);
if row == 1 && col == 1;
 s = x;
 I = 1;
 return
end % if
if row == 1
 dim = 2;
end % if
if col == 1
 dim = 1;
end % if

dhl = dd_h(x) + dd_l(x);
% this is cheating a bit
[y,I] = sort(dhl,dim,mode);

% we have to construct s
s = dd_zeros(row,col);

if dim == 1
 for i = 1:col
  s(:,i) = x(I(:,i),i);
 end % for i
 return
else % dim = 2
 for i = 1:row
  s(i,:) = x(i,I(i,:));
 end % for i
end % if dim

