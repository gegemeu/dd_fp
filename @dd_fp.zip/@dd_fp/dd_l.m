function decl = dd_l(x);
%DD_L low part of a DD word 

%
% Author G. Meurant
% May 2023
%

[row,col] = size(x);
decl = zeros(row,col);

for i = 1:row
 for j = 1:col
  decl(i,j) = x(i,j).l;
 end % for j
end % for i

