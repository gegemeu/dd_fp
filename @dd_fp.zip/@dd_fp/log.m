function c = log(a);
%LOG componentwise natural logarithm of a DD floating point number or array

%
% Author G. Meurant
% May 2023
%

[na,ma] = size(a);

if na == 1 && ma == 1
 c = dd_log(a);
 
else
 c = a;
 [na,ma] = size(a);
 for i = 1:na
  for j = 1:ma
   c(i,j) = dd_log(a(i,j));
  end % for j
 end % for j
 
end % if



