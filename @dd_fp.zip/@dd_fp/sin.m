function s = sin(a);
%SIN componentwise sine of a DD floating point number or matrix

% input in radians

%
% Author G. Meurant
% May 2023
%

[na,ma] = size(a);

if na == 1 && ma == 1
 s = dd_sin(a);
 
else
 s = a;
 [na,ma] = size(a);
 for i = 1:na
  for j = 1:ma
   s(i,j) = dd_sin(a(i,j));
  end % for j
 end % for j
 
end % if



