function xr = isreal(x);
%ISREAL is x real for a DD number or array?

%
% Author G. Meurant
% May 2023
%

xh = dd_h(x);
xl = dd_l(x);

xr = isreal(xh) && isreal(xl);

