function x = lt(a,b);
%LT less than function for DD numbers or arrays

%
% Author G. Meurant
% May 2023


if isa(a, 'dd_fp')
 a1 = dd_h(a);
 a2 = dd_l(a);
else
 a1 = a;
 a2 = 0;
end
if isa(b, 'dd_fp' )
 b1 = dd_h(b);
 b2 = dd_l(b);
else
 b1 = b;
 b2 = 0;
end
x = (a1 < b1) | ( (a1 == b1) & (a2 < b2));

