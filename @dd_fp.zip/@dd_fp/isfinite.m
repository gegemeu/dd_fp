function xf = isfinite(x);
%ISFINITE is x finite for a DD number or array?

%
% Author G. Meurant
% May 2023
%

xh = dd_h(x);
xl = dd_l(x);

xf = isfinite(xh) & isfinite(xl);

% xf = all(all(xf));




