function X = subsasgn(X,S,Y)
%SUBSASGN for DD floating point

%
% Author G. Meurant
% May 2023
%

if isa(Y,'dd_fp')
 
 [nx,mx] = size(X);
 [ny,my] = size(Y);
 if ny > nx || my > mx
  error('subsasgn: The dimension of  Y is too large')
 end
 Z(nx,mx) = struct('h',[],'l',[]);
 sl = length(S.subs);
 indi = S.subs{1};
 if sl > 1
  indj = S.subs{2};
 else
  indj = 1;
 end
 if length(indi) == 1 && strcmp(indi,':')
  indi = [1:nx];
 end
 if length(indj) == 1 && strcmp(indj,':')
  indj = [1:mx];
 end
 n = length(indi);
 m = length(indj);
 if ny ~= 1 || my ~= 1
  if n ~= ny || m ~= my
   %
   error('subsasgn: The dimensions are not compatible')
  end
  for i =1:n
   for j=1:m
    Z(indi(i),indj(j)).h = Y(i,j).h;
    Z(indi(i),indj(j)).l = Y(i,j).l;
   end % for j
  end % for i
  X(S.subs{:}) = class(Z(S.subs{:}),'dd_fp');
  
 else
  % Y is a scalar
  for i =1:n
   for j=1:m
    Z(indi(i),indj(j)).h = Y.h;
    Z(indi(i),indj(j)).l = Y.l;
   end % for i
  end % for i
  X(S.subs{:}) = class(Z(S.subs{:}),'dd_fp');
 end
 
else
 Xd = dd_h(X) + dd_l(X);
 Xd = subsasgn(Xd,S,Y);
 X = dd_fp(Xd);
end

