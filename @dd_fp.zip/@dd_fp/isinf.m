function xf = isinf(x);
%ISINF is x finite for a DD number or array?

%
% Author G. Meurant
% May 2023
%

xh = dd_h(x);
xl = dd_l(x);

xf = isfinf(xh) | isinf(xl);

% xf = all(all(xf));




