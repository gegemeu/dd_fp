function x = lu_solver(b,L,U,p);
%LU_SOLVER linear solver for a DD system

% L U x = b(p)

% b is a DD vector

%
% Author G. Meurant
% May 2023
%

b = b(p);

% solve L y = b
n = size(L,1);

y = dd_zeros(n,1);
y(1) = dd_div_dd(b(1), L(1,1));

for k = 2:n
 s = dot(L(k,1:k-1), y(1:k-1));
 y(k) = dd_minus_dd(b(k), s); % L(k,k) = 1
end % for k

% solve of U x = y
x = dd_zeros(n,1);
x(n) = dd_div_dd(y(n), U(n,n));

for k = n-1:-1:1
 s = dot(U(k,k+1:n), x(k+1:n));
 x(k) = dd_div_dd(dd_minus_dd(y(k), s), U(k,k));
end % for k

