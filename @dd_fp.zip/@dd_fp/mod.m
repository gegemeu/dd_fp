function v = mod(v,b);
%MOD mod for DD numbers

%
% Author G. Meurant
% May 2023
%

[row,col] = size(v);
[rowb,colb] = size(b);

if isa(b,'double')
 if rowb == 1 && colb == 1
  b = b * ones(row,col);
 end % if
 b = dd_fp(b);
else
 if rowb == 1 && colb == 1
  b = dd_times_dd(b, dd_fp(ones(row,col)));
 end % if rowb
end % if

v = dd_minus_dd(v, times(b, floor(dd_divH_dd(v,b))));


