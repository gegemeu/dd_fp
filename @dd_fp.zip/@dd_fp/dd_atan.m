function t = dd_atan(a);
%DD_ATAN inverse tangent function for a DD number

%
% Author G. Meurant
% May 2023
%

one = dd_fp(1);

den = sqrt( dd_plus_dd(one, dd_times_dd(a, a)));

t = dd_asin( dd_div_dd(a, den));

