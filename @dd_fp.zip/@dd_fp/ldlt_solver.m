function x = ldlt_solver(b,L,d);
%LDLT_SOLVER linear solver for a DD SPD system

% L diag(d) L^T x = b

% b is a DD vector
% L, d from chol_d

%
% Author G. Meurant
% May 2023
%

% solve L y = b
n = size(L,1);

y = dd_zeros(n,1);
y(1) = dd_div_dd(b(1), L(1,1));

for k = 2:n
 s = dot(L(k,1:k-1), y(1:k-1));
 y(k) = dd_minus_dd(b(k), s); % L(k,k) = 1
end % for k

% division by d
y = dd_divH_dd(y,d);

% solve of L^T x = y
Lt  = transpose(L);
x = dd_zeros(n,1);
x(n) = dd_div_dd(y(n), Lt(n,n));

for k = n-1:-1:1
 s = dot(Lt(k,k+1:n), x(k+1:n));
 x(k) = dd_div_dd(dd_minus_dd(y(k), s), Lt(k,k));
end % for k

