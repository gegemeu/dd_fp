function z = sqrt(x);
%SQRT square root of a DD number  or array

%
% Author G. Meurant
% May 2023
%

xh = dd_h(x);
xl = dd_l(x);

[row,col] = size(x);
z(row,col) = struct('h',[],'l',[]);

for i = 1:row
 for j = 1:col
  if xh(i,j) + xl(i,j) < 0
   z(i,j).h = NaN;
   z(i,j).l = NaN;
  elseif xh(i,j) + xl(i,j) == 0
   z(i,j).h = 0;
   z(i,j).l = 0;
  else
   xx = struct('h',xh(i,j),'l',xl(i,j));
   xs = 1 ./ sqrt(xh(i,j));
   vx = xh(i,j) .* xs;
   [p,r] = ddfp_TwoProdb(vx,vx);
   t = ddfp_dd_minus_dd(xx,ddfp_set_dd(p,r));
   [s,r] = ddfp_2sum(vx,t.h .* (xs * 0.5));
   z(i,j).h = s;
   z(i,j).l = r;
  end % if
 end % for j
end % for i

z = class(z,'dd_fp');



