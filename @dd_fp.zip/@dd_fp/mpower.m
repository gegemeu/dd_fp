function c = mpower(a,p);
%MPOWER a .^ p for DD numbers

% p can only be an integer

% Be careful, for DD numbers, this is almost similar to power

%
% Author G. Meurant
% May 2023
%

[n,m] = size(p);
if n ~= 1 || m ~= 1
 error(' mpower: The second argument must be a scalar integer')
end % if

if ~isequal(uint64(p),p)
 error(' mpower: the second argument must be an integer')
end % if

bin = dd_fp(p);
modp = mod(abs(p),2);
mone = dd_fp(-1);

[na,ma] = size(a);
c = a;

if p == 2
 c = a * a;
 return
elseif p == 3
 c = a * a * a;
 return
elseif p == 4
 c = a * a * a * a;
 return
elseif p == 5
 c = a * a * a * a * a;
 return
else
 % for p > 5, it is the same as a.^p !!!!!
 warning('mpower: For p > 5, it is the same as a.^p !!!!!')
 
 for i = 1:na
  for j = 1:ma
   c(i,j) = exp(dd_times_dd(bin, log(abs(a(i,j)))));
   if modp == 1 && dd_h(a(i,j)) < 0
    c(i,j) = dd_times_dd(c(i,j),mone);
   end % if
  end % for j
 end % for j
 
end % if p



