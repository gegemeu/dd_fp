function z = dd_div_dd(x,y);
%DD_DIV_DD division of two dd numbers 

% Muller's algorithm

% Input:
% x = double-double number, structure (x.h,x.l)
% y = double-double number, structure (y.h,y.l) 
%
% Output:
% z = double-double number, structure (z.h,z.l)

%
% Author G. Meurant
% May 2023

xh = x.h;
xl = x.l;
yh = y.h;
yl = y.l;
th = xh / yh;
r = dd_times_fp(y,th);
rh = r.h;
rl = r.l;
[ph,pl] = ddfp_2sum(xh,-rh);
dh = pl - rl;
dl = dh + xl;
d = ph + dl;
tl = d / yh;
[zh,zl] = ddfp_fast2sum(th,tl);

z = struct('h',zh,'l',zl);

z = class(z,'dd_fp');






