function xf = isnan(x);
%ISNAN is x a NaN for a DD number or array?

%
% Author G. Meurant
% May 2023
%

xh = dd_h(x);
xl = dd_l(x);

xf = isnan(xh) | isnan(xl);

% xf = all(all(xf));




