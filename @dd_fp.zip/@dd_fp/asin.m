function s = asin(a);
%ASIN inverse sine function for a DD number or array

%
% Author G. Meurant
% May 2023
%

[na,ma] = size(a);

if na == 1 && ma == 1
 s = dd_asin(a);
 
else
 s = a;
 [na,ma] = size(a);
 for i = 1:na
  for j = 1:ma
   s(i,j) = dd_asin(a(i,j));
  end % for j
 end % for j
 
end % if

