function c = dd_cos(a);
%DD_COS cosine function for a DD number

%
% Author G. Meurant
% May 2023
%

s = dd_sin(a); % sine

% c = sqrt(1 - s^2);  this is to maintain s^2 + c^2 = 1 to working precision
% if s is close to 1, 1 - s^2 can be negative

one = dd_fp(1);
os = dd_minus_dd( one, dd_times_dd(s,s));

hl = dd_h(a) + dd_l(a);
if hl == 0
 c = dd_fp(1);
 return
end % if

c = sqrt(os); % this is > 0

y = abs(a);
z = rem(hl,2*pi);

if z > pi/2 && z < 3*pi/2
 c = c * dd_fp(-1);
end % if

