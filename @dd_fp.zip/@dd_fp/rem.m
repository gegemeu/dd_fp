function x = rem(x,b);
%REM remainder after division for DD numbers or arrays

%
% Author G. Meurant
% May 2023
%

if ~isa(b,'dd_fp')
 b = dd_fp(b);
end % if

x = dd_minus_dd(x, dd_timesH_dd(b, fix(dd_divH_dd(x, b))));

