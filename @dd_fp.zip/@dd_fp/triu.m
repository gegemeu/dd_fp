function c = triu(a,k);
%TRIU upper triangular part of a DD floating point matrix

%
% Author G. Meurant
% May 2023
%

if nargin == 1
 k = 0;
end % if

c = a;

[na,ma] = size(a);

B = triu(ones(na,ma),k) == 0;

c(B) = dd_fp(0);

