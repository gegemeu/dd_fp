function z = uplus(x);
%UPLUS z = +x

%
% Author G. Meurant
% May 2023
%

z = x;

