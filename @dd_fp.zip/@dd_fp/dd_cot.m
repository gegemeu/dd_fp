function c = dd_cot(a);
%DD_COT cotangent function for a DD number

%
% Author G. Meurant
% May 2023
%

one = dd_fp(1);

c = dd_div_dd(one, dd_tan(a));



