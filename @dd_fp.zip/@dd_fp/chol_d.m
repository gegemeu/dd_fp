function [L,d] = chol_d(A);
%CHOL_D L D L^T factorization of a DD matrix, ijk version

% this is a slow code, use it only for small matrices

% Input:
% A = symmetric positive definite matrix
%
% Output:
% L = lower triangular matrix
% d = vector, such that A = L diag(d) L^T

%
% Author G. Meurant
% May 2023
%

n = size(A,1);
d = dd_zeros(n,1);
temp = dd_zeros(n,1);

L = tril(A);

d(1) = A(1,1);
L(1,1) = dd_fp(1);

for i = 2:n
 temp(1:i) = A(i,1:i);
 for j = 1:i
  if j ~= i
   L(i,j) = temp(j) / d(j);
  end % if
  for k = j+1:i
   temp(k) = temp(k) - temp(j) * L(k,j);
  end % for k
 end   % for j
 d(i) = temp(i);
 L(i,i) = dd_fp(1);
end % for i 

dh = dd_h(d);
for i = 1:n
 if dh(i) <= 0
  error(' chol_d: The matrix is not positive definite')
 end % if
end % for i




 
 
 
 
 
