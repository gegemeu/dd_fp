function c = dd_log(a);
%DD_LOG natural logarithm of a DD number

%
% Author G. Meurant
% May 2023
%

ah = dd_h(a);
al = dd_l(a);

if ah + al <= 0
%  error(' dd_log: a must be a positive number')
 c = dd_fp(NaN,NaN);
 return
end % if

% ln2 = dd_fp(6.931471805599453e-01,2.319046813846300e-17); % log(2) = 0.69314718055994528622676398299518
% %ln2 = dd_fp(0.69314718055994528622676398299518);
% 
% dec = ah + al;
% pow = log2(dec);
% if abs(2^pow - dec) <= eps
%  c = dd_times_dd(ln2,dd_fp(pow));
%  return
% end % if
% 
% % Lg1 = floatp(6.666666666666735130e-01,nbits);
% Lg1 = dd_fp(6.666666666666734e-01,9.887923813067800e-17);
% % Lg1 = ddfp_dec2dd(6.666666666666735130e-01);
% % Lg2 = floatp(3.999999999940941908e-01,nbits);
% Lg2 = dd_fp(3.999999999940942e-01,2.108773225484306e-17);
% % Lg2 = ddfp_dec2dd(3.999999999940941908e-01);
% % Lg3 = floatp(2.857142874366239149e-01,nbits);
% Lg3 = dd_fp(2.857142874366239e-01,3.417947348760553e-17);
% % Lg3 = ddfp_dec2dd(2.857142874366239149e-01);
% % Lg4 = floatp(2.222219843214978396e-01,nbits);
% Lg4 = dd_fp(2.222219843214977e-01,1.029111149596085e-16);
% % Lg4 = ddfp_dec2dd(2.222219843214978396e-01);
% % Lg5 = floatp(1.818357216161805012e-01,nbits);
% Lg5 = dd_fp(1.818357216161803e-01,8.689202786113515e-17);
% % Lg5 = ddfp_dec2dd(1.818357216161805012e-01);
% % Lg6 = floatp(1.531383769920937332e-01,nbits);
% Lg6 = dd_fp(1.531383769920935e-01,1.013322455459265e-16);
% % Lg6 = ddfp_dec2dd(1.531383769920937332e-01);
% % Lg7 = floatp(1.479819860511658591e-01,nbits);
% Lg7 = dd_fp(1.531383769920935e-01,1.013322455459265e-16);
% % Lg7 = ddfp_dec2dd(1.479819860511658591e-01);
% 
% % ln2_hi = 355 / 512;
% % ln2_lo = -2.121944400546905827679e-4; % ln2_hi + ln2_lo = log(2)
% 
% [fd,ed] = log2(dec);
% f = dd_fp(fd);
% e = dd_fp(ed);
% one = dd_fp(1);
% f = dd_minus_dd(f,one);
% hfsq = dd_times_dd(f,dd_times_dd(f,dd_fp(0.5)));
% 
% two = dd_fp(2);
% % s = dd_div_dd(f,dd_plus_dd(f,two));
% s = dd_div_dd(f,dd_plus_dd(f,dd_fp(2)));
% z = dd_times_dd(s,s);
% w = dd_times_dd(z,z);
% t1 = dd_times_dd(w, dd_plus_dd(Lg2, ddd_times_dd(w, dd_plus_dd(Lg4, dd_times_dd(w, Lg6)))));
% t2 = dd_times_dd(z, dd_plus_dd(Lg1, dd_times_dd(w, dd_plus_dd(Lg3,...
%  dd_times_dd(w, dd_plus_dd(Lg5, dd_times_dd(w, Lg7)))))));
% R = dd_plus_dd(t2,t1);
% 
% if ed == 0 
%  c = dd_minus_dd(f, dd_minus_dd(hfsq, dd_times_dd(s, dd_plus_dd(hfsq, R))));
% %  l = f - s * (f - R); 
% else
% % l = e * ln2_hi - ((hfsq - (s * (hfsq + R) + e * ln2_lo )) - f);
% % ln2_hi = 355 / 512;
% % ln2_hi = ddfp_dd_div_dd(ddfp_dec2dd(355),ddfp_dec2dd(512));
% c = dd_minus_dd(dd_times_dd(e, ln2), dd_minus_dd(dd_minus_dd(hfsq, dd_times_dd(s,...
%  dd_plus_dd(hfsq, R))), f));
% % l = e * ln2 - ((s * (f - R) ) - f);
% end % if

% Newton iteration

c = dd_fp(log(ah),0);
for k = 1:3
 s0 = dd_exp(c);
 s1 = dd_minus_dd(a, s0);
 s2 = dd_div_dd(s1, s0);
 s1 = dd_plus_dd(c, s2);
 c = s1;
end % for k
