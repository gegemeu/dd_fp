function c = dd_acos(a);
%DD_ACOS inverse cosine function for a DD number

%
% Author G. Meurant
% May 2023
%

nbits = 104;

dec = dd_h(a) + dd_l(a);

if abs(dec) > 1
 error(' dd_acos: The argument must have an absolute value less than or equal to 1')
end % if

if abs(dec) < 2^(-nbits)
 dd_pi = dd_fp('pi');
 c = dd_div_dd(dd_pi,dd_fp(2));
 return
end % if

if abs(dec - 1) < 2^(-nbits)
 c = dd_fp(0);
 return
end % if

if abs(dec + 1) < 2^(-nbits)
 c = dd_fp('pi');
 return
end % if

one = dd_fp(1);
two = dd_fp(2);
pif = dd_fp('pi');
onehalf = dd_div_dd(one,dd_fp(2));

if dec > 0.5
 c = dd_times_dd(two, dd_asin(sqrt( dd_times_dd(onehalf, dd_minus_dd(one, a)))));
 return
end % if

if dec < -0.5
 c = dd_minus_dd(pif, dd_times_dd(two, dd_asin(sqrt( dd_times_dd(onehalf, dd_plus_dd(one, a))))));
 return
end % if

pis2 = dd_div_fp(pif,dd_fp(2));
c = dd_minus_dd(pis2, dd_asin(a));







