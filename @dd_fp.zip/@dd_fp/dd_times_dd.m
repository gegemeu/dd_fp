function zz = dd_times_dd(x,y);
%DD_TIMES_DD multiplication of two DD words or arrays

% Muller's algorithm

% Input:
% x = double-double number, structure (x.h,x.l)
% y = double-double number, structure (y.h,y.l)
%
% Output:
% z = double-double number, structure (z.h,z.l)

%
% Author G. Meurant
% May 2023

[row,col] = size(x);
[rowy,coly] = size(y);

if row == 1 && col == 1 && rowy == 1 && coly == 1
 % two scalars
 xh = x.h;
 xl = x.l;
 yh = y.h;
 yl = y.l;
 [ch,cl1] = ddfp_TwoProd(xh,yh);
 tl1 = xh * yl;
 tl2 = xl * yh;
 cl2 = tl1 + tl2;
 cl3 = cl1 + cl2;
 [zh,zl] = ddfp_fast2sum(ch,cl3);
 z = struct('h',zh,'l',zl);
elseif row+col > 2 && rowy == 1 && coly == 1
 % x DD array and y DD scalar
 z(row,col) = struct('h',[],'l',[]);
 for i = 1:row
  for j = 1:col
   xh = x(i,j).h;
   xl = x(i,j).l;
   yh = y.h;
   yl = y.l;
   [ch,cl1] = ddfp_TwoProd(xh,yh);
   tl1 = xh * yl;
   tl2 = xl * yh;
   cl2 = tl1 + tl2;
   cl3 = cl1 + cl2;
   [zh,zl] = ddfp_fast2sum(ch,cl3);
   z(i,j) = struct('h',zh,'l',zl);
  end % for j
 end % for i
elseif row == 1 && col == 1 && rowy+coly > 2
 % x DD scalar and y DD array
 z(rowy,coly) = struct('h',[],'l',[]);
 for i = 1:rowy
  for j = 1:coly
   xh = x.h;
   xl = x.l;
   yh = y(i,j).h;
   yl = y(i,j).l;
   [ch,cl1] = ddfp_TwoProd(xh,yh);
   tl1 = xh * yl;
   tl2 = xl * yh;
   cl2 = tl1 + tl2;
   cl3 = cl1 + cl2;
   [zh,zl] = ddfp_fast2sum(ch,cl3);
   z(i,j) = struct('h',zh,'l',zl);
  end % for j
 end % for i
else
 % two arrays
 if col ~= rowy
  error('dd_times_dd: Incompatible dimensions')
 end % if
 % matrix-matrix product
 z(row,coly) = struct('h',[],'l',[]);
 for i = 1:row
  for j = 1:coly
   s = ddfp_dec2dd(0,0);
   for k = 1:col
    %     p = ddfp_dd_times_dd(x(i,k),y(k,j));
    xh = x(i,k).h;
    xl = x(i,k).l;
    yh = y(k,j).h;
    yl = y(k,j).l;
    [ch,cl1] = ddfp_TwoProd(xh,yh);
    tl1 = xh * yl;
    tl2 = xl * yh;
    cl2 = tl1 + tl2;
    cl3 = cl1 + cl2;
    [zh,zl] = ddfp_fast2sum(ch,cl3);
    p = struct('h',zh,'l',zl);
    s = ddfp_dd_plus_dd(s,p);
   end % for k
   z(i,j) = s;
  end % for j
 end % for i
 
end % if row

zz = class(z,'dd_fp');






