function [xdd,Idd,sdd] = dd_fp(x,y);
%DD_FP constructor for the class ddfp, DD floating point arithmetic

% x is a double precision scalar or matrix or strings

% xdd is a structure with fields: h, l (double double format with high and low parts)

%
% Author G. Meurant
% May 2023
%

Idd = [];
sdd = [];
[rowx,colx] = size(x);

if nargin == 1
 if isa(x,'dd_fp')
  xdd = x;
  return
 end % if
 
 if ischar(x) && strcmpi(x,'pi')
  xdd = ddfp_pi;
  xdd = class(xdd,'dd_fp');
  return
 end % if
 
 if ischar(x) && strcmpi(x,'eps')
  xdd = ddfp_eps;
  xdd = class(xdd,'dd_fp');
  return
 end % if
 
 if ischar(x) 
  [xh,xl] = ddfp_str2dd(x);
  xdd = dd_fp(xh,xl);
  return
 end % if
 
 if issparse(x)
  x = full(x);
 end % if
 
 xdd = ddfp_dec2dd(x);
 xdd = class(xdd,'dd_fp');
 
else
 
 if issparse(x) || issparse(y)
  if ischar(y) && strcmpi(y,'sparse')
   % x is a sparse matrx, we convert it to a DD CSR format
   % to be able to do matrix vector product
   [xdd,Idd,sdd] = ddfp_dec2csr(x);
   xdd = class(xdd,'dd_fp');
   return
  elseif ischar(x) && strcmpi(x,'sparse')
   % y is a sparse matrx, we convert it to a DD CSR format
   % to be able to do matrix vector product
   [xdd,Idd,sdd] = ddfp_dec2csr(y);
   xdd = class(xdd,'dd_fp');
   return
  else
   x = full(x);
   y = full(y);
  end % if
 end % if
 
 if isa(x,'dd_fp') || isa(y,'dd_fp')
  error('dd_fp: The two arguments must be floating point numbers')
 end % if
 if isa(x,'double') && isa(y,'double')
  xdd = ddfp_dec2dd(x,y);
  xdd = class(xdd,'dd_fp');
  return
 end % if
 
end % if nargin
