function v = fix(v);
%FIX fix for DD numbers

%
% Author G. Meurant
% May 2023
%

x1 = fix(dd_h(v));
x2 = zeros(size(x1));
I = find(x1 == dd_h(v));
vl = dd_l(v);
x2(I) = fix(vl(I));
[x1,x2] = ddfp_fast2sum(x1,x2); 
v = dd_fp(x1,x2);



