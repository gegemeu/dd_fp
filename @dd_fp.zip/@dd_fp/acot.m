function t = acot(a);
%ACOT inverse cotangent function for a DD number or array

%
% Author G. Meurant
% May 2023
%

[na,ma] = size(a);

if na == 1 && ma == 1
 t = dd_acot(a);
 
else
 t = a;
 [na,ma] = size(a);
 for i = 1:na
  for j = 1:ma
   t(i,j) = dd_acot(a(i,j));
  end % for j
 end % for j
 
end % if