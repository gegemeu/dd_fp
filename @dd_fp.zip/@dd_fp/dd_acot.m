function c = dd_acot(a);
%DD_ACOT inverse cotangent function for a DD number

%
% Author G. Meurant
% May 2023
%

one = dd_fp(1);

den = sqrt( dd_plus_dd(one, dd_times_dd(a, a)));

c = dd_asin( dd_div_dd(one, den));

