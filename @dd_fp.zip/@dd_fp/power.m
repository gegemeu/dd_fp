function c = power(a,p);
%POWER a .^ p for DD numbers

% p can only be an integer 

%
% Author G. Meurant
% May 2023
%

[n,m] = size(p);
if n ~= 1 || m ~= 1
 error(' power: The second argument must be a scalar integer')
end % if

if ~isequal(uint64(p),p)
 error(' power: the second argument must be an integer')
end % if

bin = dd_fp(p);
modp = mod(abs(p),2);
mone = dd_fp(-1);

[na,ma] = size(a);
c = a;

for i = 1:na
 for j = 1:ma
  c(i,j) = exp(dd_times_dd(bin, log(abs(a(i,j)))));
  if modp == 1 && dd_h(a(i,j)) < 0
   c(i,j) = dd_times_dd(c(i,j),mone);
  end % if
 end % for j
end % for j

