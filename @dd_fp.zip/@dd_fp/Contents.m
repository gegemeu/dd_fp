% @DD_FP
%
% Files
%   abs              - absolute value of a DD number or array
%   acos             - inverse cosine function for a DD number or array
%   acot             - inverse cotangent function for a DD number or array
%   asin             - inverse sine function for a DD number or array
%   atan             - inverse tangent function for a DD number or array
%   ceil             - ceil for DD numbers
%   chol             - Cholesky factorization of a DD matrix, ijk version
%   chol_d           - L D L^T factorization of a DD matrix, ijk version
%   cos              - componentwise cosine of a DD floating point point number or matrix
%   cot              - componentwise cotangent of a DD floating point point number or matrix
%   ctranspose       - transpose of a (real) DD matrix
%   dd_acos          - inverse cosine function for a DD number
%   dd_acot          - inverse cotangent function for a DD number
%   dd_asin          - inverse sine function for a DD number
%   dd_atan          - inverse tangent function for a DD number
%   dd_cos           - cosine function for a DD number
%   dd_cot           - cotangent function for a DD number
%   dd_div_dd        - division of two dd numbers 
%   dd_divH_dd       - element by element division of two DD arrays
%   dd_exp           - exponential of a DD number
%   dd_fp            - constructor for the class ddfp, DD floating point arithmetic
%   dd_h             - high part of a DD word 
%   dd_l             - low part of a DD word 
%   dd_log           - natural logarithm of a DD number
%   dd_minus_dd      - subtraction of two dd words
%   dd_orth_mgs_col  - (double) orthogonalisation of the columns of A
%   dd_plus_dd       - addition of two dd words or arrays
%   dd_sin           - sine function for a DD number
%   dd_tan           - tangent function for a DD number
%   dd_times_dd      - multiplication of two DD words or arrays
%   dd_times_dd_csrv - matrix-vector product of a CSR DD matrix and a DD vector
%   dd_times_fp      - multiplication of a dd number by a floating-point number
%   dd_timesH_dd     - element by element product of two DD arrays
%   det              - determinant of a square matrix
%   diag             - diagonal function for a DD matrix or vector
%   disp             - displays the DD floating point as a sum
%   disp_dd          - displays a DD number or array
%   display          - display for a DD floating point number
%   dot              - dot product of two DD vectors
%   double           - convert a DD number or array to fp
%   eq               - equal function for DD numbers or arrays
%   exp              - componentwise exponential of a DD floating point number or matrix
%   fix              - fix for DD numbers
%   floor            - floor for DD numbers
%   ge               - greater or equal than function for DD numbers or arrays
%   gt               - greater than function for DD numbers or arrays
%   inv              - inverse of a DD matrix
%   isfinite         - is x finite for a DD number or array?
%   isinf            - is x finite for a DD number or array?
%   isnan            - is x a NaN for a DD number or array?
%   isreal           - is x real for a DD number or array?
%   ldivide          - ldivide element by element division of two DD arrays
%   ldlt_solver      - linear solver for a DD SPD system
%   le               - less than or equal function for DD numbers or arrays
%   log              - componentwise natural logarithm of a DD floating point number or array
%   log10            - componentwise base 10 logarithm of a DD number or matrix
%   log2             - base 2 logarithm of a DD number 
%   lt               - less than function for DD numbers or arrays
%   lu               - triangular factorization of a DD matrix
%   lu_solver        - linear solver for a DD system
%   max              - max function for DD numbers or arrays
%   min              - min function for DD numbers or arrays
%   minus            - subtraction of two DD floating point numbers or matrices
%   mldivide         - division of two DD floating point numbers or matrices
%   mod              - mod for DD numbers
%   mpower           - a .^ p for DD numbers
%   mrdivide         - division of two DD floating point numbers or matrices
%   mtimes           - product of two DD floating point numbers or matrices
%   ne               - non equal function for DD numbers or arrays
%   norm             - norm of a DD vector or matrix
%   normv            - l2 norm of a DD vector
%   plus             - addition of two DD floating point numbers or matrices
%   power            - a .^ p for DD numbers
%   prod             - prod function for DD numbers or arrays
%   qr               - qr factorization of a DD matrix
%   rdivide          - rdivide element by element division of two DD arrays
%   rem              - remainder after division for DD numbers or arrays
%   repmat           - repetition function for a DD vector or array
%   reshape          - reshape function for DD vectors or arrays
%   sin              - componentwise sine of a DD floating point number or matrix
%   sort             - sort function for DD arrays
%   sqrt             - square root of a DD number  or array
%   subsasgn         - for DD floating point
%   subsref          - for DD floating point
%   sum              - sum function for DD numbers or arrays
%   tan              - componentwise tangent of a DD floating point point number or matrix
%   times            - componentwise product of two DD floating point numbers or matrices
%   times_dd_csrv    - matrix-vector product of a CSR DD matrix and a DD vector
%   trace            - trace of a DD matrix
%   transpose        - transpose of a (real) DD matrix
%   triang_solver    - solver for a DD triangular matrix
%   tril             - lower triangular part of a DD floating point matrix
%   triu             - upper triangular part of a DD floating point matrix
%   uminus           - z = -x
%   uplus            - z = +x
