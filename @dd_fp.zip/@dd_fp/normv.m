function znorm = normv(x);
%NORMV l2 norm of a DD vector

%
% Author G. Meurant
% May 2023
%

s = dot(x,x);
znorm = sqrt(s);

