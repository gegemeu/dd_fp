function [Q,R] = qr(A);
%QR qr factorization of a DD matrix

% This is done with the modified Gram-Schmidt algorithm with reorthogonalization
% It is in fact qr(A,0)

%
% Author G. Meurant
% May 2023
%

[Q,R] = dd_orth_mgs_col(A,dreorth);

if nargout == 1
 Q = R;
end % if

