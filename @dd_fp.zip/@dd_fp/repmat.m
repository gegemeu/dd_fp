function x = repmat(x,varargin);
%REPMAT repetition function for a DD vector or array

%
% Author G. Meurant
% May 2023
%

xh = dd_h(x);
xl = dd_l(x);

x = dd_fp(repmat(xh, varargin{:}), repmat(xl, varargin{:}));


