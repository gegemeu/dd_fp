function dec = double(x);
%DOUBLE convert a DD number or array to fp

%
% Author G. Meurant
% May 2023
%

[row,col] = size(x);
dec = zeros(row,col);

for i = 1:row
 for j = 1:col
  dec(i,j) = x(i,j).h + x(i,j).l;
 end % for j
end % for i

