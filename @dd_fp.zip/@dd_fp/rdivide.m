function z = rdivide(x,y);
%rdivide element by element division of two DD arrays

% similar to dd_divH_dd

% Input:
% x,y = DD arrays

%
% Author G. Meurant
% May 2023
%

[rowx,colx] = size(x);
[rowy,coly] = size(y);

if rowy == 1 && coly == 1
 y = y * dd_ones(rowx,colx);
 rowy = rowx;
 coly = colx;
end % if

if rowx ~= rowy || colx ~= coly
 error('rdivide: Incompatible dimensions of inputs')
end % if

if rowx == 1 && colx == 1
 z = dd_div_dd(x,y);
 return
end % if

z = dd_zeros(rowx,colx);

for i = 1:rowx
 for j = 1:colx
  z(i,j) = dd_div_dd(x(i,j),y(i,j));
 end % for j
end % for i

