function z = uminus(x);
%UMINUS z = -x

%
% Author G. Meurant
% May 2023
%

z = x * dd_fp(-1);

