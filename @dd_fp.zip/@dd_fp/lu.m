function [L,U,P,p] = lu(A);
%LU triangular factorization of a DD matrix

% A is a square DD matrix

% [L,U,P] = ddfp_lu(A) produces a unit lower triangular matrix L, an upper triangular matrix U, 
%  and a permutation vector p, so that L * U = P' * A

% p is the permutation vector, P is the equivalent permutation matrix

%
% Author G. Meurant
% May 2023
%

n = size(A,1);
p = (1:n)';

for k = 1:n-1
 
 % find index of largest element below diagonal in k-th column
 % this is cheating a bit, we look at the h-part
 vec = dd_h(A(k:n,k));
 [rd,m] = max(abs(vec)); 
 m = m + k - 1;
 r = A(m,k);
 
 % skip elimination if column is zero
 if rd ~= 0
  
  % swap pivot row
  if m ~= k
   A([k m],:) = A([m k],:);
   p([k m]) = p([m k]);
  end
  
  % compute multipliers
  for i = k+1:n;
   A(i,k) = dd_div_dd(A(i,k), A(k,k)); 
  end % for i
  
  % update the remainder of the matrix
  for i = k+1:n
   for j = k+1:n;
    A(i,j) = dd_minus_dd(A(i,j), dd_times_dd(A(i,k), A(k,j))); % subtraction of an outer product
   end % for j
  end % for i
 end % if
end % for k

if nargout > 1
 % separate result
 I = dd_eye(n);
 L = dd_plus_dd(tril(A,-1), I);
 U = triu(A);
 
 if nargout > 2
  % construct P
  II = eye(n);
  P = II(:,p);
 end % if
end % if


