function s = dd_sin(a);
%DD_SIN sine function for a DD number

%
% Author G. Meurant
% May 2023
%

dec = abs(a);
% dec = mod(dec,2*pi);
dd_pi = dd_fp('pi');
pi2 = dd_times_fp(dd_pi,2);
dec = mod(dec,pi2);
dec_old = dec;
dec = dd_h(dec) + dd_l(dec);
nbits = 104;

if dec <= 2^(-nbits)
 s = dd_fp(0);
 return
end % if

if abs(dec - pi/2) <= 2^(-nbits) 
 s = dd_fp(1);
 return
end % if

if abs(dec - 3*pi/2) <= 2^(-nbits)
 s = dd_fp(-1);
 return
end % if

if abs(dec - pi) <= 2^(-nbits)
 s = dd_fp(0);
 return
end % if

% convert dec back to DD
a = dec_old;

% pi1 = ddfp_set_dd(0.318309886183790,0.67154e-15); % 1 / pi 
one = dd_fp(1,0);
pi1 = dd_div_dd(one,dd_pi);

if dd_h(a) > 0
 sig = 1;
else 
 sig = -1;
end % if

y = abs(a);
ypi1 = dd_times_dd(y,pi1);
n = round(ypi1.h + ypi1.l);  %%%%%%%to do

x1 = floor(y); 
x2 = dd_minus_dd(y,x1);
cn = dd_fp(3217,0);
cd = dd_fp(1024,0);
c1 = dd_div_dd(cn,cd);
% c2 = dd_fp(-8.908910206761537e-6,3.56617e-23);
% c1 + c2 = pi
c2 = dd_minus_dd(dd_pi,c1);

% ( (x1 - n * c1) + x2) - n * c2
f = dd_minus_dd(dd_plus_dd(dd_minus_dd(x1, dd_times_fp(c1,n)), x2), dd_times_fp(c2,n)); 

% s1 = floatp(-1.66666666666666324348e-01,nbits);
% s1 = ddfp_dec2dd(-1.66666666666666e-01,0.324348e-16);
% one = ddfp_set_dd(1,0);
% six = ddfp_set_dd(-6,0);
% s1 = ddfp_dd_div_dd(one,six); % -1 / 3!
% s1 = ddfp_dec2dd(-1.66666666666666324348e-01);
s1 = dd_fp(ddfp_str2dd_2('-1.66666666666666324348e-01'));
%s1 = ddfp_dec2dd( ddfp_str2dd('-1.66666666666666324348e-01'));
% s2 = floatp(8.33333333332248946124e-03,nbits);
% s2 = ddfp_dec2dd(8.333333333322489e-03,0.46124e-18);
% onetw = ddfp_set_dd(120,0);
% s2 = ddfp_dd_div_dd(one,onetw); % 1 / 5!
% s2 = ddfp_dec2dd(8.33333333332248946124e-03);
s2 = dd_fp(ddfp_str2dd_2('8.33333333332248946124e-03'));
% s3 = floatp(-1.98412698298579493134e-04,nbits);)
% s3 = ddfp_dec2dd(-1.98412698298579e-04,0.493134e-19);
% fth = ddfp_set_dd(-5040);
% s3 = ddfp_dd_div_dd(one,fth); % -1 / 7!
% s3 = ddfp_dec2dd(-1.98412698298579493134e-04);
s3 = dd_fp(ddfp_str2dd_2('-1.98412698298579493134e-04'));
% s4 = floatp(2.75573137070700676789e-06,nbits);
% s4 = ddfp_dec2dd(2.75573137070700e-06,0.676789e-21);
% trt = ddfp_set_dd(362880,0);
% s4 = ddfp_dd_div_dd(one,trt); % 1 / 9!
% s4 = ddfp_dec2dd(2.75573137070700676789e-06);
s4 = dd_fp(ddfp_str2dd_2('2.75573137070700676789e-06'));
% s5 = floatp(-2.50507602534068634195e-08,nbits);
% s5 = ddfp_dec2dd(-2.50507602534068e-08,0.634195e-23);
% tth = ddfp_set_dd(-39918948,0);
% tth = ddfp_set_dd(-39916800,0);
% s5 = ddfp_dd_div_dd(one,tth); % -1 / 11!
% s5 = ddfp_dec2dd(-2.50507602534068634195e-08);
s5 = dd_fp(ddfp_str2dd_2('-2.50507602534068634195e-08'));
% s6 = floatp(1.58969099521155010221e-10,nbits);
% s6 = ddfp_dec2dd(1.58969099521155e-10,0.010221e-25);
% smi = ddfp_set_dd(6290530694,0);
% smi = ddfp_set_dd(6227020800,0);
% s6 = ddfp_dd_div_dd(one,smi); % 1 / 13!
% s6 = ddfp_dec2dd(1.58969099521155010221e-10);
s6 = dd_fp(ddfp_str2dd_2('1.58969099521155010221e-10'));

if (dd_h(a)+dd_l(a)) == 0
 s = dd_fp(0);
 return
end % if
fd = dd_h(f) + dd_l(f);
if abs(fd) > 2^(-32) % ?????
 
 z = dd_times_dd(f,f);
 v = dd_times_dd(z,f);
 % r =  s2 + z * (s3 + z * (s4 + z * (s5 + z * s6)))
 r =  dd_plus_dd(s2, dd_times_dd(z, dd_plus_dd(s3, dd_times_dd(z,...
  dd_plus_dd(s4, dd_times_dd(z, dd_plus_dd(s5, dd_times_dd(z, s6)))))))); 
 % s = f + v * (s1 + z * r)
 s = dd_plus_dd(f, dd_times_dd(v ,(dd_plus_dd(s1, dd_times_dd(z, r))))); 
 
else
 
 s = f;
 
end % if

if sig ~= 1
 s = dd_times_fp(s,sign(dd_h(f)));
end % if

if mod(n,2) ~= 0
 s = dd_times_dd(s,dd_fp(-1));
end % if




