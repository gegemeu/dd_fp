function disp_dd(x);
%DISP_DD displays a DD number or array

[row,col] = size(x);

if row == 1 && col == 1
 xh = dd_h(x);
 xl = dd_l(x);
 fprintf('\n %20.15e + %20.15e ',xh,xl)
 fprintf('\n')
else
 if row == 1 || col == 1
  rc = max(row,col);
  if rc > 50
   warning('ddfp_disp_dd: The array is too large to be displayed in this way')
   return
  end % if
  Xh = dd_h(x);
  Xl = dd_l(x);
  fprintf('\n high \n')
%   disp(Xh(:))
  disp(Xh)
  fprintf(' low \n')
%   disp(Xl(:))
  disp(Xl)
  return
 end % if row
 if row > 50 || col > 50
  warning('ddfp_disp_dd: The array is too large to be displayed in this way')
  return
 end % if
 % x is an array
 %  Xh = zeros(row,col);
 %  Xl = zeros(row,col);
 %  for i = 1:row
 %   for j = 1:col
 %    Xh(i,j) = x(i,j).h;
 %    Xl(i,j) = x(i,j).l;
 %   end % for j
 %  end % for j
 Xh = dd_h(x);
 Xl = dd_l(x);
 fprintf('\n high \n')
 disp(Xh)
 fprintf(' low \n')
 disp(Xl)
 %  XX = [Xh  Xl];
 %  disp(XX)
end % if