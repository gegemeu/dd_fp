function c = log10(a);
%LOG10 componentwise base 10 logarithm of a DD number or matrix

%
% Author G. Meurant
% May 2023
%

[na,ma] = size(a);

% l10 = floatp(2.302585092994045684017991455,nbits); % log(10)
l10 = dd_fp(2.302585092994046e+00,-2.170756223382250e-16); % log(10)

if na == 1 && ma == 1
 c = dd_log(a);
 c = dd_div_dd(c, l10);
 
else
 c = a;
 [na,ma] = size(a);
 for i = 1:na
  for j = 1:ma
   c(i,j) = dd_log(a(i,j));
   c(i,j) = dd_div_dd(c(i,j), l10);
  end % for j
 end % for j
 
end % if



