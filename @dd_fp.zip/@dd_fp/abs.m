function z = abs(x);
%ABS absolute value of a DD number or array

%
% Author G. Meurant
% May 2023
%

[row,col] = size(x);

z = dd_zeros(row,col);

for i = 1:row
 for j = 1:col
  if x(i,j).h < 0
   z(i,j).h = -x(i,j).h;
   z(i,j).l = -x(i,j).l;
  else
   z(i,j) = x(i,j);
  end % if x
 end % for j
end % for i

