function [z,I] = min(a,b,dim);
%MIN min function for DD numbers or arrays

% We assume that the low parts are small

%
% Author G. Meurant
% May 2023
%

[row,col] = size(a);
I = [];

if nargin < 3
 dim = 1;
 if nargin < 2
  b = [];
 end
end

A = dd_h(a);
if ~isempty(b)
 B = dd_h(b);
end % if

if isempty(b)
 if row == 1 || col == 1
  [Z,I] = min(A);
  z = a(I);
  return
 else
  [Z,I] = min(A,[],dim);
 end % if row
end % if

if ~isempty(b)
 z = a;
 for i = 1:row
  for j = 1:col
   if A(i,j) < B(i,j)
    z(i,j) = a(i,j);
   else
    z(i,j) = b(i,j);
   end % if A
  end % for j
 end % for i
else
 if dim == 1
  z = dd_zeros(1,col);
  for i = 1:col
   z(1,i) = a(I(i),i);
  end % for i
 else
  z = dd_zeros(row,1);
  for i = 1:row
   z(i,1) = a(i,I(i));
  end % for i
 end % if dim
end % id ~isempty


