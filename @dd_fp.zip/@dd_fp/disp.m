function disp(x)
% DISP displays the DD floating point as a sum

%
% Author G. Meurant
% May 2020
%

disp_dd(x)

