function x = triang_solver(X,b,s);
%TRIANG_SOLVER solver for a DD triangular matrix

% X DD triangular matrix
% b is a DD vector, s is a string = 'lower' or 'upper'

%
% Author G. Meurant
% May 2023
%

if nargin == 2 || strcmpi(s,'lower')
 low = 1;
else
 low = 0;
end

% solve X y = b
n = size(X,1);

if low == 1
 % lower triangular matrix
 
 x = dd_zeros(n,1);
 x(1) = dd_div_dd(b(1), X(1,1));
 
 for k = 2:n
  s = dot(X(k,1:k-1), x(1:k-1));
  x(k) = dd_div_dd(dd_minus_dd(b(k), s), X(k,k));
 end % for k
 
else
 
 % upper triangular matrix
 x = dd_zeros(n,1);
 x(n) = dd_div_dd(b(n), X(n,n));
 
 for k = n-1:-1:1
  s = dot(X(k,k+1:n), x(k+1:n));
  x(k) = dd_div_dd(dd_minus_dd(b(k), s), X(k,k));
 end % for k
 
end % if low

