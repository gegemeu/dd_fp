function z = inv(x);
%INV inverse of a DD matrix

%
% Author G. Meurant
% May2023
%

[row,col] = size(x);

if row == 1 && col == 1 && (dd_h(x) + dd_l(x) ~= 0)
 z = dd_fp(1) / x;
 return
end % if

[L,U,P,p] = lu(x);
I = dd_eye(row,col);
z = dd_zeros(row,col);

for i = 1:col
 b = I(:,i);
 z(:,i) = lu_solver(b,L,U,p);
end % for i

